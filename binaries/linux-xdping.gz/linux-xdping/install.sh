#!/bin/sh
#
# Install script for Linux XDPing.
#
# Copyright(C) 2016 Citrix Systems.
#
# Usage:
# ./install.sh
#

XDPING_PACKAGE_VER=1.4.0.29-0

# Check root user
if [[ $EUID -ne 0 ]]; then
    echo "XDPing can only be installed as root." 1>&2
    exit 1
fi

# Check Linux operating system
OS=$(uname | tr "[:upper:]" "[:lower:]")

if [ $OS == linux ]; then
    # Check supported processor architecture
    ARCH=$(uname -m)

    if [ $ARCH != x86_64 ]; then
        echo "XDPing only supports x86-64." 1>&2
        exit 1
    fi

    # Check supported Linux distribution
    if [ -f /etc/lsb-release -o -d /etc/lsb-release.d ]; then
        DISTRO=$(lsb_release -is | tr "[:upper:]" "[:lower:]")
    else
        DISTRO=$(ls -d /etc/[A-Za-z]*[_-]release | grep -v "lsb-release" | grep -v "os-release" | grep -v "system-release" | cut -d'/' -f3 | cut -d'-' -f1 | cut -d'_' -f1 | tr "[:upper:]" "[:lower:]")
    fi

    case $DISTRO in
        suse*|novell*|opensuse*)  XDPING_RPM_DIR="SuSE";;
        red*|cent*|fedora*)       XDPING_RPM_DIR="RHEL";;
    esac
else
    echo "XDPing only supports Linux." 1>&2
    exit 1
fi

# Install XDPing package
if [ ! -z $XDPING_RPM_DIR ]; then
    echo "Installing Linux XDPing..."
    rpm -i $XDPING_RPM_DIR/xdping-$XDPING_PACKAGE_VER.x86_64.rpm
else
    echo "XDPing is not supported on this Linux distribution." 1>&2
    exit 1
fi

