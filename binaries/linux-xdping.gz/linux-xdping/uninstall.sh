#!/bin/sh
#
# Uninstall script for Linux XDPing.
#
# Copyright(C) 2016 Citrix Systems.
#
# Usage:
# ./uninstall.sh
#

# Check root user
if [[ $EUID -ne 0 ]]; then
    echo "XDPing can only be uninstalled as root." 1>&2
    exit 1
fi

rpm -e xdping

